# -*- coding: utf-8 -*-
"""
travel_timing_expenditure_2025.csv + accommodation_type_2025.csv 전처리 스크립트

- '01_데이터_전처리_보고서.md'에 기술된 로직(결측치/이상치/손상레코드 처리, 파생변수 생성)을
  그대로 pandas로 재현한다.
- 사용법:
    python 02_preprocess_travel_data.py \
        --timing data/processed/travel_timing_expenditure_2025.csv \
        --accommodation data/processed/accommodation_type_2025.csv \
        --out data/cleaned/travel_timing_expenditure_2025_cleaned.csv

근거/출처는 01_데이터_전처리_보고서.md 각 절을 참고할 것.
"""
import argparse
import pandas as pd
import numpy as np

# ---------------------------------------------------------------------------
# 매핑 테이블 (보고서 4장 근거와 동일)
# ---------------------------------------------------------------------------
PD_TO_NIGHTS = {
    '1박 2일': 1, '2박 3일': 2, '3박 4일': 3, '4박 5일': 4, '5박 6일': 5, '6박 7일 이상': 6,
}
COM_TO_NUM = {'혼자서': 1, '2명': 2, '3명': 3, '4명': 4, '5명 이상': 5}
INCOME_TO_MID = {
    '300만원 미만': 250, '300~500만원 미만': 400, '500~700만원 미만': 600, '700만원 이상': 800,
}
TOTAL_BIN_TO_MID = {
    '10만원 미만': 5, '10~20만원 미만': 15, '20~30만원 미만': 25,
    '30~40만원 미만': 35, '40만원 이상': 45,
}
CATEGORY_BIN_TO_MID = {
    '1만원 미만': 0.5, '1~3만원 미만': 2, '3~5만원 미만': 4,
    '5~7만원 미만': 6, '7~10만원 미만': 8.5, '10만원 이상': 12,
}
SEASON_MAP = {12: '겨울', 1: '겨울', 2: '겨울', 3: '봄', 4: '봄', 5: '봄',
              6: '여름', 7: '여름', 8: '여름', 9: '가을', 10: '가을', 11: '가을'}
WEEKDAY_KR = ['월', '화', '수', '목', '금', '토', '일']

COST_FIELDS = ['TOUR_TOT_CT_VALUE', 'TOUR_LDGMNT_CT_VALUE', 'TOUR_FOOD_CT_VALUE',
               'TOUR_TRNSPORT_CT_VALUE', 'TOUR_SHOPNG_CT_VALUE', 'TOUR_ACTVTY_CT_VALUE',
               'TOUR_ETC_CT_VALUE']

XY_PAIR_BASES = ['TOUR_CTPRVN_NM', 'TOUR_SIGNGU_NM', 'TOUR_COM_NMPR_NM', 'TOUR_PD_VALUE',
                  'SEXDSTN_FLAG_CD', 'AGRDE_FLAG_NM', 'MRRG_AT_NM', 'CHLDRN_TY_NM',
                  'OCCP_NM', 'HSHLD_INCOME_DGREE_NM']


def normalize_region(s: str) -> str:
    """거주지/여행지 광역지자체명 표기 통일 (인천광역시 vs 인천시 등)."""
    if pd.isna(s):
        return s
    for suf in ['특별자치시', '특별자치도', '광역시', '특별시', '도', '시']:
        s = s.replace(suf, '')
    return s.strip()


def load_and_clean(timing_path: str, accommodation_path: str) -> pd.DataFrame:
    df1 = pd.read_csv(timing_path, dtype=str, keep_default_na=False)
    df2 = pd.read_csv(accommodation_path, dtype=str, keep_default_na=False)

    # -----------------------------------------------------------------
    # 1. 데이터 파악: _x/_y 중복 컬럼 검증 (보고서 1-3절)
    # -----------------------------------------------------------------
    mismatch_report = {}
    for base in XY_PAIR_BASES:
        xcol, ycol = f'{base}_x', f'{base}_y'
        if xcol in df1.columns and ycol in df1.columns:
            mismatch_report[base] = int((df1[xcol] != df1[ycol]).sum())
    print('[검증] _x/_y 불일치 건수 (0이면 _y 제거 가능):', mismatch_report)

    # -----------------------------------------------------------------
    # 3. 손상 레코드 처리
    # -----------------------------------------------------------------
    # 3-1) 여행시작일 > 조사일 (날짜 논리 오류) -> 삭제하지 않고 플래그
    df1['ANOMALY_DATE_FLAG'] = (
        df1['TOUR_BEGIN_DE'].astype(int) > df1['EXAMIN_BEGIN_DE_x'].astype(int)
    ).astype(int)

    # 3-2) 동일 RESPOND_ID + 동일 TOUR_BEGIN_DE인데 내용이 다른 충돌 레코드
    #      -> 그룹 내 결측("모름"/공란) 수가 가장 적은(가장 완전한) 행만 채택
    df1['_missing_score'] = (df1 == '').sum(axis=1) + (df1 == '모름').sum(axis=1)
    df1 = df1.sort_values('_missing_score')
    df1 = df1.drop_duplicates(subset=['RESPOND_ID', 'TOUR_BEGIN_DE'], keep='first')
    df1 = df1.drop(columns=['_missing_score']).sort_index()

    # 3-4) 중복 _y 컬럼 제거 (불일치 0건 확인된 경우에만 안전)
    if all(v == 0 for v in mismatch_report.values()):
        drop_cols = [f'{b}_y' for b in XY_PAIR_BASES if f'{b}_y' in df1.columns]
        df1 = df1.drop(columns=drop_cols)
        rename_map = {f'{b}_x': b for b in XY_PAIR_BASES if f'{b}_x' in df1.columns}
        df1 = df1.rename(columns=rename_map)
    else:
        print('[경고] _x/_y 불일치가 발견되어 자동 제거를 건너뜁니다. 수동 확인 필요.')

    # -----------------------------------------------------------------
    # 2. 결측치 처리
    # -----------------------------------------------------------------
    # COM_TWO_TY~SIX_TY: 구조적 결측('해당없음')과 COM_ONE_TY 진짜 결측('모름') 구분
    for c in ['COM_TWO_TY', 'COM_THREE_TY', 'COM_FOUR_TY', 'COM_FIVE_TY', 'COM_SIX_TY']:
        if c in df1.columns:
            df1[c] = df1[c].replace('', '해당없음')
    if 'COM_ONE_TY' in df1.columns:
        df1['COM_ONE_TY'] = df1['COM_ONE_TY'].replace('', '모름')

    # 지출 7항목 전부 '모름'인지 플래그 (부분결측 0건 실측 확인 -> 대체 대신 플래그)
    df1['HAS_EXPENDITURE_RESPONSE'] = (~(df1[COST_FIELDS] == '모름').all(axis=1)).astype(int)

    # -----------------------------------------------------------------
    # 4. 파생변수 생성
    # -----------------------------------------------------------------
    dt = pd.to_datetime(df1['TOUR_BEGIN_DE'], format='%Y%m%d')
    df1['TRIP_MONTH'] = dt.dt.month
    df1['TRIP_SEASON'] = df1['TRIP_MONTH'].map(SEASON_MAP)
    df1['TRIP_WEEKDAY'] = dt.dt.dayofweek.map(lambda i: WEEKDAY_KR[i])
    df1['IS_WEEKEND_START'] = df1['TRIP_WEEKDAY'].isin(['금', '토', '일']).astype(int)

    df1['TRIP_NIGHTS_NUM'] = df1['TOUR_PD_VALUE'].map(PD_TO_NIGHTS)
    df1['GROUP_SIZE_NUM'] = df1['TOUR_COM_NMPR_NM'].map(COM_TO_NUM)
    df1['INCOME_MIDPOINT_MANWON'] = df1['HSHLD_INCOME_DGREE_NM'].map(INCOME_TO_MID)

    df1['COST_TOTAL_MID_MANWON'] = df1['TOUR_TOT_CT_VALUE'].map(TOTAL_BIN_TO_MID)
    for c, out in [('TOUR_LDGMNT_CT_VALUE', 'COST_LODGING_MID_MANWON'),
                   ('TOUR_FOOD_CT_VALUE', 'COST_FOOD_MID_MANWON'),
                   ('TOUR_TRNSPORT_CT_VALUE', 'COST_TRANSPORT_MID_MANWON'),
                   ('TOUR_SHOPNG_CT_VALUE', 'COST_SHOPPING_MID_MANWON'),
                   ('TOUR_ACTVTY_CT_VALUE', 'COST_ACTIVITY_MID_MANWON'),
                   ('TOUR_ETC_CT_VALUE', 'COST_ETC_MID_MANWON')]:
        df1[out] = df1[c].map(CATEGORY_BIN_TO_MID)

    df1['COST_PER_PERSON_MANWON'] = df1['COST_TOTAL_MID_MANWON'] / df1['GROUP_SIZE_NUM'].clip(lower=1)

    # accommodation_type 조인: RESPOND_ID별 최신월(EXAMIN_YM) 레코드 사용
    df2_sorted = df2.sort_values('EXAMIN_YM')
    latest2 = df2_sorted.drop_duplicates(subset='RESPOND_ID', keep='last').set_index('RESPOND_ID')

    df1['HOME_REGION'] = df1['RESPOND_ID'].map(latest2['ANSWRR_OC_AREA_NM'])
    df1['DOM_TRAVEL_PREFERENCE'] = df1['RESPOND_ID'].map(latest2['DMSTC_TOUR_TY_VALUE'])
    df1['OVERSEAS_TRAVEL_PREFERENCE'] = df1['RESPOND_ID'].map(latest2['OVSEA_TOUR_TY_VALUE'])

    def home_dest_match(row):
        if pd.isna(row['HOME_REGION']):
            return '정보없음'
        dest = row['TOUR_CTPRVN_NM']
        if dest in ('구체적인 지역 모름', '모름'):
            return '목적지불명'
        return '일치' if normalize_region(row['HOME_REGION']) == normalize_region(dest) else '불일치'

    df1['HOME_DEST_MATCH'] = df1.apply(home_dest_match, axis=1)

    # 반복 응답자 플래그 (보고서 1-3절 근거)
    dup_counts = df1['RESPOND_ID'].value_counts()
    df1['IS_REPEAT_RESPONDENT'] = df1['RESPOND_ID'].map(lambda i: int(dup_counts.get(i, 0) > 1))

    return df1


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--timing', required=True, help='travel_timing_expenditure_2025.csv 경로')
    ap.add_argument('--accommodation', required=True, help='accommodation_type_2025.csv 경로')
    ap.add_argument('--out', required=True, help='정제된 CSV 출력 경로')
    args = ap.parse_args()

    cleaned = load_and_clean(args.timing, args.accommodation)
    cleaned.to_csv(args.out, index=False, encoding='utf-8-sig')
    print(f'[완료] {len(cleaned)}행, {cleaned.shape[1]}열 -> {args.out}')


if __name__ == '__main__':
    main()
